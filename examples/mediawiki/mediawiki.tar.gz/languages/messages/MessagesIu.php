<?php
/** Inuktitut (ᐃᓄᒃᑎᑐᑦ/inuktitut)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment Macro language; kept for backward compatibility
 *
 */

$fallback = 'ike-cans';
