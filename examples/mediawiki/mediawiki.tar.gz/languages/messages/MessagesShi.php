<?php
/** Tachelhit (Tašlḥiyt/ⵜⴰⵛⵍⵃⵉⵜ)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Dalinanir
 * @author Ebe123
 * @author Zanatos
 */

$messages = array(
# User preference toggles
'tog-underline' => 'krrj du izdayn:',
'tog-justify' => 'skr lɛrd n-stor ɣ togzimin aygiddi',
'tog-hideminor' => 'Ḥbu imbddl imaynutn lli fssusnin.',
'tog-hidepatrolled' => 'Hide patrolled edits in recent changes',
'tog-newpageshidepatrolled' => 'Ḥbu tisniwin lli n tsagga gr tisniwin timaynutin',
'tog-extendwatchlist' => 'Ssaɣḍ umuɣ n tisniwin lli n ttfur bac ad n ẓṛṛa imbddln maci ɣir imaynutn',
'tog-usenewrc' => 'Skr s imbddln imaynutn lli n sastwa (ira mayad JavaScript)',
'tog-numberheadings' => 'nmra n nsmiat wahdot',
'tog-showtoolbar' => 'sbaynd tizikrt n tbddil(JavaScript)',
'tog-editondblclick' => 'Ẓrig tisniwin ad s uklik snat wal ( ira mayad JavaScript)',
'tog-editsection' => 'Mmurzm i imbddln n w-ayyawn izdayn n « [Bddel] »',
'tog-editsectiononrightclick' => 'Yan uklik s tsga tafasi f uzwl n w-ayyaw bac ad tsbadlt ɣtad (ira JavaScript)',
'tog-showtoc' => 'Mel Taflwit n tngawin (i tisniwin lli dar 3 w-ayyawn)',
'tog-rememberpassword' => 'Askti nu ukcum ɣ Urdinaturad (Iɣ kullu tggut $1 {{PLURAL:$1|Ass|Ass}})',
'tog-watchcreations' => 'Zaydn tasniwin lli skrɣ i umuɣ n tilli ssuġiɣ.',
'tog-watchdefault' => 'Zaydn tasniwin lli tżrigɣ i umuɣ n tilli tsaggaɣ',
'tog-watchmoves' => 'Zayd tisniwin lli smattayɣ i tilli tsggaɣ.',
'tog-watchdeletion' => 'Zaydn tasniwin lli kkesɣ i tilli tsaggaɣ',
'tog-minordefault' => 'Rcm kullu iẓṛign li fssusni sɣiklli gan.',
'tog-previewontop' => 'Mel iẓri amzwaru ɣ uflla ɣ taɣzut n imbddln',
'tog-previewonfirst' => 'Ml imzray n imbdln imzwura',
'tog-nocache' => 'ador itsjjal lmtasaffih tawriqt ad',
'tog-enotifwatchlistpages' => 'sifd yi tabrat  igh ibdl kra yat twriqt ghomdfor inu',
'tog-enotifusertalkpages' => 'sifd yi tabrat  igh tbdl tawriqt ohokko-no',
'tog-enotifminoredits' => 'sifd yi tabrat  i ibdln mziynin',
'tog-enotifrevealaddr' => 'Ml tansa n tibratin inu ɣ umuɣ n tbratin',
'tog-shownumberswatching' => 'Ml uṭṭun n Midn lli swurn ɣ tasna yad',
'tog-oldsig' => 'Asmmaql (Tiẓṛi) n ukrraj n ufus lli illan:',
'tog-fancysig' => 'Skr akrrag n ufus s taɣarast  n  wikitext (bla azday utumatik)',
'tog-externaleditor' => 'Swwur s yan umẓṛg u uṭṛiṣ n brra ( i imskarn lli bahra ḥrcnin, ira mayad riglaj iẓlin ɣ urdinatur)',
'tog-externaldiff' => 'Skr s yan umsnaḥya abrrani ( i midn lli bahra ḥrcnin, mayad ira riglaj ɣ urdinatur)',
'tog-showjumplinks' => 'Srɣ izdayn « Amuddu » d « acnubc » niḍ « Asiǧl » ɣ uflla n tasna',
'tog-uselivepreview' => 'Skr s umẓri amaynu izrbn (ira JavaScript) (Arm)',
'tog-forceeditsummary' => 'Ayyit tini iɣ ur iwiɣ imsmun n imbdln',
'tog-watchlisthideown' => 'hbo ghayli bdlgh gh omdfor inu',
'tog-watchlisthidebots' => 'hba ghayli bdln robotat gh omdfor inu',
'tog-watchlisthideminor' => 'Ḥbu ibdln mzinin ɣ umdfur inu',
'tog-watchlisthideliu' => 'Ḥbu ibdln n wili skrn midn llin iqqiydn ɣu umdfr inu.',
'tog-watchlisthideanons' => 'Ḥbu ibdl n midn lli urittuyssanin ɣ umdfr inu',
'tog-watchlisthidepatrolled' => 'Ḥbu ibdln lli nssugga  ɣu umuɣ n umdfr',
'tog-ccmeonemails' => 'Azn n yyi tunɣit n tbratin liyid uzn wiyaḍ',
'tog-diffonly' => 'Ad ur tml may illan ɣ tisniwin, ml ɣir mattnt isnaḥyan',
'tog-showhiddencats' => 'sbaynd tsnifat ihbanin',
'tog-norollbackdiff' => 'hiyd lfarq baad lqiyam bstirjaa',

'underline-always' => 'dima',
'underline-never' => 'ḥtta manak',
'underline-default' => 'ala hssad regalhe n lmotasaffih',

# Font style option in Special:Preferences
'editfont-style' => 'lkht n lmintaqa nthrir',
'editfont-default' => 'ala hssab reglage n lmotasaffih',
'editfont-monospace' => 'kht ard tabt',
'editfont-sansserif' => 'lkht bla zwayd',
'editfont-serif' => 'lkht szwayd',

# Dates
'sunday' => 'Asamas',
'monday' => 'Aynas',
'tuesday' => 'Asinas',
'wednesday' => 'Akras',
'thursday' => 'Akwas',
'friday' => 'asimas',
'saturday' => 'asidyas',
'sun' => 'asamas',
'mon' => 'Aynas',
'tue' => 'Asinas',
'wed' => 'Akras',
'thu' => 'Akwas',
'fri' => 'Asimwas',
'sat' => 'Asidyas',
'january' => 'Innayr',
'february' => 'brayr',
'march' => 'Mars',
'april' => 'Ibrir',
'may_long' => 'Mayyu',
'june' => 'Yunyu',
'july' => 'Yulyu',
'august' => 'Γuct',
'september' => 'Cutanbir',
'october' => 'Kṭubr',
'november' => 'Nuwanbir',
'december' => 'Dujanbir',
'january-gen' => 'Innayr',
'february-gen' => 'Brayr',
'march-gen' => 'Mars',
'april-gen' => 'Ibrir',
'may-gen' => 'Mayyu',
'june-gen' => 'Yunyu',
'july-gen' => 'Yulyu',
'august-gen' => 'Γuct',
'september-gen' => 'Cutanbir',
'october-gen' => 'Kṭubr',
'november-gen' => 'Nuwanbir',
'december-gen' => 'Dujanbir',
'jan' => 'Innayr',
'feb' => 'brayr',
'mar' => 'Mar',
'apr' => 'Ibrir',
'may' => 'Mayyuh',
'jun' => 'yunyu',
'jul' => 'yulyu',
'aug' => 'ɣuct',
'sep' => 'cutanbir',
'oct' => 'kṭuber',
'nov' => 'Nuw',
'dec' => 'Duj',

# Categories related messages
'pagecategories' => '{{PLURAL:$1|taggayt|taggayin}}',
'category_header' => 'Tisniwin ɣ taggayt "$1"',
'subcategories' => 'Du-taggayin',
'category-media-header' => 'Asdaw multimedya ɣ taggayt "$1"',
'category-empty' => 'Taggayt ad ur gis kra n tasna, du-taggayt niɣd asddaw multimidya',
'hidden-categories' => '{{PLURAL:$1|Taggayt iḥban|Taggayin ḥbanin}}',
'hidden-category-category' => 'Taggayyin ḥbanin',
'category-subcat-count' => 'Taggayt ad gis {{PLURAL:$2|ddu taggayt|$2 ddu taggayin, lli ɣ tlla {{PLURAL:$1|ɣta|ɣti $1}}}} γu flla nna.',
'category-subcat-count-limited' => 'Taggayt ad illa gis {{PLURAL:$1|ddu taggayt| $1 ddu taggayyin}} ɣid ɣ uzddar.',
'category-article-count' => 'Taggayt ad gis {{PLURAL:$2|tasna d yuckan|$2 tisniwin, lliɣ llant {{PLURAL:$1|ɣta|ɣti $1}} ɣid ɣu uzddar}}.',
'category-article-count-limited' => '{{PLURAL:$1|Tasna d yuckan tlla|Tisniwin $1 llid yuckan llant}} ɣ taggayt ad',
'category-file-count' => 'Taggayt ad gis {{PLURAL:$2|asdaw ad yuckan|$2 isdawn ad, lliɣ llant {{PLURAL:$1|ɣta|ɣti $1}} ɣid ɣ uzddar}}.',
'category-file-count-limited' => '{{PLURAL:$1|Asdaw ad yuckan illa|isdawn ad $1 llid yuckan llan}} ɣ taggayt ad',
'listingcontinuesabbrev' => 'Attfr',
'index-category' => 'Tisniwin su umatar',
'noindex-category' => 'Tisniwin bla amatar',
'broken-file-category' => 'Tisniwin ɣ llan izdayn rzanin',

'about' => 'F',
'article' => 'Mayllan ɣ tasna',
'newwindow' => 'Murzemt ɣ tasatmt tamaynut',
'cancel' => 'ḥiyyd',
'moredotdotdot' => 'Uggar...',
'mypage' => 'Tasnat inu',
'mytalk' => 'Amsgdal inu',
'anontalk' => 'Amsgdal i w-ansa yad',
'navigation' => 'Tunigin',
'and' => '&#32; d',

# Cologne Blue skin
'qbfind' => 'Af',
'qbbrowse' => 'Cabba',
'qbedit' => 'Sbadl',
'qbpageoptions' => 'Tasnat ad',
'qbmyoptions' => 'Tisnatin inu',
'qbspecialpages' => 'Tisnatin timzlay',
'faq' => 'Isqsitn li bdda tsutulnin',
'faqpage' => 'Project: Isqqsit li bdda',

# Vector skin
'vector-action-addsection' => 'Zayd amli',
'vector-action-delete' => 'Ḥiyd',
'vector-action-move' => 'Smmatti',
'vector-action-protect' => 'Ḥbu',
'vector-action-undelete' => 'Rard may mayḥiydn',
'vector-action-unprotect' => 'Ḥiyd aḥbu',
'vector-simplesearch-preference' => 'Mmurzm immalatn n icnubcn lan atig (I Vector waḥdut )',
'vector-view-create' => 'Skert',
'vector-view-edit' => 'Ara',
'vector-view-history' => 'Mel amzruy',
'vector-view-view' => 'ɣr',
'vector-view-viewsource' => 'Ẓr asagm',
'actions' => 'Imskarn',
'namespaces' => 'Ismawn n tɣula',
'variants' => 'lmotaghayirat',

'errorpagetitle' => 'Laffut',
'returnto' => 'Urri s $1.',
'tagline' => 'Ž {{SITENAME}}',
'help' => 'Asaws',
'search' => 'Acnubc',
'searchbutton' => 'Cabba',
'go' => 'Balak',
'searcharticle' => 'Ftu',
'history' => 'Amzruy n tasna',
'history_short' => 'Amzruy',
'updatedmarker' => 'Tuybddal z tizrink li iğuran',
'printableversion' => 'Tasna nu sugz',
'permalink' => 'Azday Bdda illan',
'print' => 'Siggz',
'edit' => 'Ẓreg (bddel)',
'create' => 'Skr',
'editthispage' => 'Ara tasna yad',
'create-this-page' => 'Sker tasna yad',
'delete' => 'Ḥiyd',
'deletethispage' => 'Ḥiyd tasna yad',
'undelete_short' => 'Yurrid {{PLURAL:$1|yan umbddel|$1 imbddeln}}',
'protect' => 'Ḥbu',
'protect_change' => 'Abddel',
'protectthispage' => 'Ḥbu tasna yad',
'unprotect' => 'Kksas aḥbu',
'unprotectthispage' => 'Kks aḥbu i tasnatad',
'newpage' => 'tawriqt tamaynut',
'talkpage' => 'Sgdl f tasna yad',
'talkpagelinktext' => 'Sgdl (mdiwil)',
'specialpage' => 'Tasna izlin',
'personaltools' => 'Imasn inu',
'postcomment' => 'Ayyaw amaynu',
'articlepage' => 'Mel mayllan ɣ tasna',
'talk' => 'Amsgdal',
'views' => 'Ẓr.. (Mel)',
'toolbox' => 'Tanaka n imasn',
'userpage' => 'Ẓr n tasna n umsqdac',
'projectpage' => 'Ẓr tasna n tuwwuri',
'imagepage' => 'Ẓr tasna n-usddaw',
'mediawikipage' => 'Ẓr tasna n tabrat',
'templatepage' => 'Ẓr tasna n Tamudemt',
'viewhelppage' => 'Ẓr tasna n-aws',
'categorypage' => 'Ẓr tasna n taggayt',
'viewtalkpage' => 'Ẓr amsgdal',
'otherlanguages' => 'S tutlayin yaḍnin',
'redirectedfrom' => '(Tmmuttid z $1)',
'redirectpagesub' => 'Tasna n-usmmattay',
'lastmodifiedat' => 'Imbddeln imggura n tasna yad z $1, s $2.',
'viewcount' => 'Tmmurzm tasna yad {{PLURAL:$1|yat twalt|$1 mnnawt twal}}.',
'protectedpage' => 'Tasnayat iqn ugdal nes.',
'jumpto' => 'Ftu s:',
'jumptonavigation' => 'Tunigen',
'jumptosearch' => 'Acnubc',
'view-pool-error' => 'Surf, iqddacn žayn ɣilad. mnnaw midn yaḍnin ay siggiln tasna yad. Qqel imik fad addaɣ talst at tarmt at lkmt tasna yad

$1',
'pool-timeout' => 'Tzrit tizi n uql lli yak ittuykfan. Ggutn midn lli iran ad iẓr tasna yad. Urrid yan imik..',
'pool-queuefull' => 'Umuɣ n twuri iẓun (iεmr)',
'pool-errorunknown' => 'Anzri (error) ur ittuyssan.',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'aboutsite' => 'F {{SITENAME}}',
'aboutpage' => "Project:f' mayad",
'copyright' => 'Mayllan gis illa ɣ ddu $1.',
'copyrightpage' => '{{ns:project}}:Izrfan n umgay',
'currentevents' => 'Immussutn n ɣila',
'currentevents-url' => 'Project:Immussutn n ɣilad',
'disclaimers' => 'Ur darssuq',
'disclaimerpage' => 'Project: Ur illa maddar illa ssuq',
'edithelp' => 'Aws ɣ tirra',
'edithelppage' => 'Help:Imaratn',
'helppage' => 'Help:Mayllan',
'mainpage' => 'Tasana tamzwarut',
'mainpage-description' => 'Tasna tamzwarut',
'policy-url' => 'Project:Tasrtit',
'portal' => 'Ağur n w-amun',
'portal-url' => 'Project:Ağur n w-amun',
'privacy' => 'Tasrtit n imzlayn',
'privacypage' => 'Project:Tasirtit ni imzlayn',

'badaccess' => 'Anezri (uras tufit)',
'badaccess-group0' => 'Ur ak ittuyskar at sbadelt ma trit',
'badaccess-groups' => 'Ɣaylli trit at tskrt ɣid ittuyzlay ɣir imsxdamn ɣ tamsmunt{{PLURAL:$2|tamsmunt|yat ɣ timsmuna}}: $1.',

'versionrequired' => 'Txxṣṣa $1 n MediaWiki',
'versionrequiredtext' => 'Ixxṣṣa w-ayyaw $1 n MediaWiki bac at tskrert tasna yad.
Ẓr [[Special:Version|ayyaw tasna]].',

'ok' => 'Waxxa',
'pagetitle' => '(MediaWiki)$1 - {{SITENAME}}',
'pagetitle-view-mainpage' => '{{SITENAME}}',
'retrievedfrom' => 'Yurrid z "$1"',
'youhavenewmessages' => 'Illa dark $1 ($2).',
'newmessageslink' => 'Tibratin timaynutin',
'newmessagesdifflink' => 'Imbddeln imĝura',
'youhavenewmessagesmulti' => 'Dark tibratin timaynutin ɣ $1',
'editsection' => 'Ẓreg (bddel)',
'editsection-brackets' => '[$1]',
'editold' => 'Ẓreg (bddel)',
'viewsourceold' => 'Mel aɣbalu',
'editlink' => 'Ẓreg (bddel)',
'viewsourcelink' => 'Mel aɣbalu',
'editsectionhint' => 'Ẓreg ayyaw: $1',
'toc' => 'Mayllan',
'showtoc' => 'Mel',
'hidetoc' => 'ḥbu',
'collapsible-collapse' => 'Smnuḍu',
'collapsible-expand' => 'Sfruri',
'thisisdeleted' => 'Mel niɣd rard $1?',
'viewdeleted' => 'Mel $1?',
'restorelink' => '{{PLURAL:$1|Ambddel lli imḥin|imbddel lli imḥin}}',
'feedlinks' => 'Asudm:',
'feed-invalid' => 'Anaw n usurdm ur gis iffuy umya',
'feed-unavailable' => 'Isudmn ur llanin ɣil',
'site-rss-feed' => '$1 asudm n RSS',
'site-atom-feed' => "$1 lqm n' atom",
'page-rss-feed' => '"$1" tlqim RSS',
'page-atom-feed' => '$1 azday atom',
'red-link-title' => '$1 (tasna yad ur tlli)',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main' => 'Tasnat',
'nstab-user' => 'Tasnat u-msxdam',
'nstab-media' => 'Tasnat Ntuzumt',
'nstab-special' => 'Tasna tamzlit',
'nstab-project' => 'Tasna n tuwuri',
'nstab-image' => 'Asdaw',
'nstab-mediawiki' => 'Tabrat',
'nstab-template' => 'Talɣa',
'nstab-help' => 'Tasna n-aws',
'nstab-category' => 'Taggayt',

# Main script and global functions
'nosuchaction' => 'Ur illa mat iskrn',
'nosuchactiontext' => 'Mytuskarn ɣu tansa yad ur tti tgi.

Irwas is turit tansa  skra mani yaḍnin, ulla azday ur igi amya.

Tzdar attili tamukrist ɣ {{SITENAME}}.',
'nosuchspecialpage' => 'Urtlla tasna su w-ussaɣad',
'nospecialpagetext' => '<strong>Trit yat tasna tamzlit ur illan.</strong>

Tifilit n tasnayin gaddanin ratn taft ɣid [[Special:SpecialPages|{{int:specialpages}}]].',

# General errors
'error' => 'Laffut',
'databaseerror' => 'Laffut ɣ database',
'dberrortext' => 'Tlla laffut ɣikli s tskert database.
Ulla mayad kis kra ntmukrist.
May igguran ittu isigal ɣ mayad igat.
<blockquote><tt>$1</tt></blockquote>
S ussiglad "<tt>$2</tt>".
laffut d yurrin ɣ database "<tt>$3: $4</tt>".',
'laggedslavemode' => 'Ḥan tasnayad ur gis graygan ambddel amaynu.',
'readonly' => 'Tqqn tabase',
'missing-article' => 'lqaa\'ida n lbayanat ortofa nass ad gh tawriqt  liss ikhssa asti taf limism "$1" $2.

ghikad artitsbib  igh itabaa lfrq aqdim nghd tarikh artawi skra nsfha ityohyadn.

ighor iga lhal ghika ati ran taft kra lkhata gh lbarnamaj.

ini mayad ikra [[Special:ListUsers/sysop|lmodir]] tfktas ladriss ntwriqt an.',
'missingarticle-rev' => '(lmorajaaa#: $1)',
'missingarticle-diff' => '(lfarq: $1, $2)',
'internalerror' => 'khata ghogns',
'internalerror_info' => 'khata ghogns :$1',
'fileappenderrorread' => 'Ur as nufa anɣr "$1"',
'fileappenderror' => 'orimkn anzayd "$1" s "$2".',
'filecopyerror' => 'orimkin ankopi "$1" s "$2".',
'filerenameerror' => 'ur as tufit ad tsmmut "$1" s "$2".',
'filedeleteerror' => 'Ur as yuffi ad ikkis asddaw ad « $1 ».',
'directorycreateerror' => 'Ur as tufit an tgt asddaw « $1 ».',
'filenotfound' => 'Ur as tufit ad taft "$1"',
'fileexistserror' => 'Ur as tufit ad tarat ɣ usdaw "$1" : asdaw ur illi',
'unexpected' => 'Azal (atig) llis ur nql: « $1 » = « $2 ».',
'formerror' => 'Anzri: ur as tufit an tgt tifrkit',
'badarticleerror' => 'Tigawt ad ur  as tufi ad ttuyskar ɣ tasna yad.',
'cannotdelete' => 'Ur as tufa tasna yad ad ttuykkas niɣd asdaw ad « $1 ».
Akks ad iskrt kra yaḍn',
'badtitle' => 'Azwl ur ifulkin',
'badtitletext' => 'Azwl n tasna lli trit ur igadda, ixwa, niɣd iga aswl n gr tutlayt niḍ ngr tuwwurins ur izdimzyan. Ẓr urgis tgit kra nu uskkil niɣd mnnaw lli gis ur llanin',
'viewsource' => 'Mel iɣbula',

# Virus scanner
'virus-unknownscanner' => 'antivirus oritwsan',

# Login and logout pages
'yourname' => 'smiyt o-msxdam:',
'yourpassword' => 'awal iḥdan:',
'yourpasswordagain' => 'Зawd ara awal iḥdan:',
'remembermypassword' => 'Askti nu ukcum ɣ Urdinaturad (Iɣ kullu tggut $1 {{PLURAL:$1|Ass|Ass}})',
'yourdomainname' => 'Taɣult nek',
'externaldberror' => 'Imma tlla ɣin kra lafut ɣu ukcumnk ulla urak ittuyskar at tsbddelt lkontnk nbrra.',
'login' => 'Kcm ɣid',
'nav-login-createaccount' => 'kcm / murzm Amidan',
'loginprompt' => 'You must have cookies enabled to log in to {{SITENAME}}.',
'userlogin' => 'kchem / qiyd amskhdam amaynu',
'userloginnocreate' => 'Kcm ɣid',
'logout' => 'Fuɣ',
'userlogout' => 'Fuɣ',
'notloggedin' => 'Ur tmlit mat git',
'nologin' => 'Ur trzemt amidan (lkunt) nek? $1..',
'nologinlink' => 'Murzm amidan nek (lkunt)..',
'createaccount' => 'Murzm amidan nek (lkunt)..',
'gotaccount' => 'Is nit dark amidan(lkunt)? $1.',
'gotaccountlink' => 'Kcm',
'userlogin-resetlink' => 'Ttut ismnk d tasarut n ukccum nk',
'createaccountmail' => 'S tirawt taliktunant',
'createaccountreason' => 'Maɣ:',
'badretype' => 'Tasarut lin tgit ur dis tucka.',
'userexists' => 'Asaɣ nu umsqdac li tskcmt illa yad',
'loginerror' => 'Gar akccum',
'createaccounterror' => '$1 ur as tufit at kcmt',
'loginsuccesstitle' => 'Tkcmt mzyan (tllit ɣil ɣ ifalan)',
'loginsuccess' => 'Tllit ɣilad ɣ ifalan (tzdit d tuqqna) {{GENDER:$1|||}} ar {{SITENAME}} zund « $1 ».',
'nosuchuser' => 'Asqdac « $1 » ur illi.
Ussaɣ n isqdacn ḥiln hlli.
Ẓṛ daɣ ist turit mzyan mayad, niɣd [[Special:UserLogin/signup|tmmurẓmt amiḍan amaynu]].',
'nosuchusershort' => 'Ur illa umsaws lli ilan assaɣ « $1 ». Ẓṛ ist turit mzyan mayad.',
'nouserspecified' => 'Illa fllak ad tarat assaɣ nk.',
'login-userblocked' => 'Asqdac ad ur as yufi ad ikcm. Tazdayt ɣ ifalan uras ttuyskar',
'mailmypassword' => 'sifd yi awal ihdan yadni',
'mailerror' => 'Gar azn n tbrat : $1',
'emailconfirmlink' => 'Als i tasna nk n tbratin izd nit nttat ayan.',
'loginlanguagelabel' => 'Tutlayt: $1',

# Email sending
'php-mail-error-unknown' => 'Kra ur igadda tasɣnt btbratin() n PHP.',

# Change password dialog
'resetpass' => 'bddl taguri n uzray',
'resetpass_announce' => 'Tkcmt {{GENDER:||e|(e)}} s yat tangalt lli kin ilkmt s tbrat emeil . tangaltad ur tgi abla tin yat twalt. Bac ad tkmlt tqqiyyidank kcm tangalt tamaynut nk ɣid:',
'resetpass_header' => 'Sbadl taguri n tangalt n umiḍal (compte)',
'oldpassword' => 'Awal iḥḍan aqbur',
'newpassword' => 'Awal iḥḍan amaynu:',
'retypenew' => 'Als i tirra n w-awal iḥḍan:',
'resetpass_submit' => 'Sbadl awal n uzri tkcmt',
'resetpass_success' => 'Awal n uzri nk ibudl mzyan! rad nit tilit ɣ ifalan',
'resetpass_forbidden' => 'Iwaliwn n uzri ur ufan ad badln.',
'resetpass-no-info' => 'illa fllak ad zwar tilit ɣ ifalan bac ad tkcmt s tasna yad',
'resetpass-submit-loggedin' => 'Bdl awal n ukccum (tangalt)',
'resetpass-submit-cancel' => 'ḥiyyd',
'resetpass-wrong-oldpass' => 'Awal n uzri yad niɣt walli yak ittkfan i yatwalt ur gis iffuɣ umya.
Han irwas is yad tsbadlt awal n uzri niɣd is ḍalbt yan yaḍn n yat tklit.',
'resetpass-temp-password' => 'Awal ad n uzri iga ɣir win yat tklit:',

# Edit page toolbar
'bold_sample' => 'Aḍṛiṣ iḍnin',
'bold_tip' => 'Aḍṛiṣ iḍnin',
'italic_sample' => 'Aḍṛiṣ iknan',
'italic_tip' => 'Aḍṛiṣ iknan',
'link_sample' => 'Azwl n uzday',
'link_tip' => 'Azday uwgns',
'extlink_sample' => 'http://www.example.com azwl n uzday',
'extlink_tip' => 'Azday n brra (af ur ttut amzwir http://prefix)',
'headline_sample' => 'Aḍṛiṣ n ddu uzwl',
'headline_tip' => 'Ddu-uzwl taskfalt 2',
'nowiki_sample' => 'Kcm aḍṛiṣ li ur imzln ɣid',
'nowiki_tip' => 'Zri Taseddast n wiki',
'image_tip' => 'Asdaw n illan',
'media_tip' => 'Azday s usdaw usɣmas (midya)',
'sig_tip' => 'Tirra n ufus nk (akrraj) s usakud',
'hr_tip' => 'izriri iɣzzifn (ad bahra gis ur tsgut)',

# Edit pages
'summary' => 'Tagḍwit (ⵜⴰⴳⴹⵡⵉⵜ):',
'subject' => 'Fmit/Azwl',
'minoredit' => 'Imbddl ifssusn',
'watchthis' => 'Ṭfr tasna yad',
'savearticle' => 'Ẓṛig d tḥbut',
'preview' => 'Iẓṛi amzwaru',
'showpreview' => 'Iẓṛi amzwaru',
'showlivepreview' => 'Iẓṛi izrbn',
'showdiff' => 'Mel imbddln lli ifttun',
'anoneditwarning' => "Han  ''' ur ttuyssant ''' rad ibayn IP nk ɣ umzrut n tasna yad, ur sul  iḥba tamagit nk",
'anonpreviewwarning' => 'ur ittuyssan mat tgit. Iɣ tgdl tawuri nk, tansa nk IP rad tbayn ɣ umzruy n imbdln n tasna yad.',
'missingsummary' => "'''Adakt nskti :''' ur ta tfit awal imun n imbddln nk.
Iɣ tklikkit tiklit yaḍn f tjrrayt « {{int:savearticle}} », aẓṛig rad ittuyskar blla tsnt",
'missingcommenttext' => 'Σafak skjm awnnit (aɣfawal) nk ɣ uflla.',
'summary-preview' => 'Tiẓṛi  n tagḍwit:',
'blockedtitle' => 'lmostkhdim ad itbloka',
'blockednoreason' => 'ta yan sabab oritfki',
'whitelistedittext' => 'Illa fllak ad tilit ɣ $1 bac adak ittuyskar ad tsbadlt mayllan ɣid',
'confirmedittext' => 'Illa fllak ad talst i tansa nk tbratin urta tsbadalt tisniwin.
Kcm zwar tft tansan nk tbratin ɣ [[Special:Preferences|Timssusmin n umqdac]].',
'nosuchsectiontitle' => 'Ur as tufit ad taft ayyaw ad.',
'nosuchsectiontext' => 'Turmt ad tsbadlt yan w-ayyaw lli ur illin.
Ḥaqqan is immutti s mani niɣt ittuykkas s mad tɣrit tasnayad.',
'loginreqtitle' => 'Labd ad tkclt zwar',
'loginreqlink' => 'Kcm ɣid',
'loginreqpagetext' => 'Illa fllak  $1 bac ad tẓṛt tisniwin yaḍn.',
'accmailtitle' => 'awal ihdan hatin yuznak nnit',
'newarticle' => '(Amaynu)',
'newarticletext' => "Tfrt yan uzday s yat tasna lli ur ta jju illan [{{fullurl:Special:Log|type=delete&page={{FULLPAGENAMEE}}}} ttuykkas].
Iɣ rast daɣ tskrt skcm atṛiṣ nk ɣ tanaka  yad (Tẓḍaṛt an taggt γi [[{{MediaWiki:Helppage}}|tasna u usaws]] iɣ trit inɣmisn yaḍn).
Ivd tlkmt {{GENDER:||e|(e)}} ɣis bla trit, klikki f tajrrayt n '''urrir''' n iminig nk (navigateur).",
'noarticletext' => 'ɣilad ur illa walu may ityuran  f tasnatad ad, tzdart at [[Special:Search/{{PAGENAME}}|search for this page title]] in other pages,
<span class="plainlinks">[{{fullurl:{{#Special:Log}}|page={{FULLPAGENAMEE}}}} search the related logs],
ulla cabba  [{{fullurl:{{FULLPAGENAME}}|action=edit}} edit this page]</span>.',
'noarticletext-nopermission' => 'Ur illa may itt yuran ɣ tasna tad.
Ẓr [[Special:Search/{{PAGENAME}}|search for this page title]] ɣ tisnatin yaḍnin,
ulla <span class="plainlinks">[{{fullurl:{{#Special:Log}}|page={{FULLPAGENAMEE}}}}search the related logs]</span>.',
'updated' => '(mohdata)',
'note' => "'''molahada:'''",
'previewnote' => "'''Ad ur ttut aṭṛiṣ ad iga ɣir amzwaru urta illa ɣ ifalan !'''",
'editing' => 'taẓṛgt $1',
'editingsection' => 'Ẓrig $1 (tagzumt)',
'yourtext' => 'nss nek',
'storedversion' => 'noskha ityawsjaln',
'yourdiff' => 'lforoq',
'copyrightwarning' => "ikhssak atst izd kolchi tikkin noun ɣ {{SITENAME}} llan ɣdo $2 (zr $1 iɣ trit ztsnt uggar).
iɣ ortrit ayg ɣayli torit ḥor artisbadal wnna ka-iran, attid ortgt ɣid.<br />
ikhssak ola kiyi ador tnqilt ɣtamani yadni.
'''ador tgat ɣid ɣayli origan ḥor iɣzark orilli lidn nbab-ns!'''",
'templatesused' => '{{PLURAL:$1|Tamuḍimt lli nsxdm|Timuḍimin}} ɣ tasna yad:',
'templatesusedpreview' => '{{PLURAL:$1|Tamuḍimt llis nskar |Timuḍam lli sa nskar }} ɣ iẓriyad amzwaru :',
'template-protected' => 'Agdal',
'template-semiprotected' => 'Azin-ugdal',
'hiddencategories' => '{{PLURAL:$1|Taggayt iḥban|Taggayin ḥbanin}} lli ɣtlla tasba yad :',
'permissionserrorstext-withaction' => 'Urak ittuyskar  {{IGGUT:||e|(e)}} s $2, bac {{PLURAL:$1|s wacku yad|iwackutn ad}} :',
'recreate-moveddeleted-warn' => '"Balak z ɣin: tmmaɣt addaɣ tskrt tasna lli yad ittuykkasn."
Ẓr zwar is ifulki ad tfrt imbddln ɣ tasna yad. Tanɣmast n mad ittuykkasn d mad ibddln ttla ɣid ɣ uzddar.',
'moveddeleted-notice' => 'Tasna yad ttuykkas. inɣmas n tuyykkas d issmmattayn nsn llan ɣ ɣ ufflla i tusna.',
'log-fulllog' => 'Zṛ anɣmas izun (usmmid)',
'edit-hook-aborted' => 'Imbddln ur ttuyskarnin.. Ur ittuyssan maɣ',
'edit-gone-missing' => 'Ur iga as f was tasnayad
Ḥaqqan is iḥiyd kra n yan',
'edit-conflict' => 'Maɣn ɣid imbddln',
'edit-no-change' => 'Ambdeln nk nxxln acku ur ibudl walu ɣ uṭṛiṣ.',
'edit-already-exists' => 'Tasnayad tlla yadlli. ur as tufit ast daɣ tskrt.',

# Parser/template warnings
'post-expand-template-inclusion-warning' => 'Han:  tasna yad illa gis tuggut n tmuḍimin. Kra gitsnt ur ran illint.',
'post-expand-template-inclusion-category' => 'Tisniwin lli bahra ittafn tuggut n tmuḍimin',
'post-expand-template-argument-warning' => 'Balak: Tasna ivɣ gis uggar n iɣwar n tmudimt lli ur tti ttajjan an gis tilli
Tigira n ujbbad ns, ar takka yat tayafut bahra imqqurn,  ɣayan afan ur ttili.',
'post-expand-template-argument-category' => 'Tisna lliɣ llan iɣwarn n tmudimt urta lan atig',
'parser-template-loop-warning' => 'Tamuḍimt ikrknnin ttyufa ɣid : [[$1]]',

# History pages
'viewpagelogs' => 'Ẓr timhlin lli ittuskarn ɣ tasna yad',
'currentrev-asof' => 'Amseggar amǧuru  n $1',
'revisionasof' => 'Askttay yaḍn f $1',
'revision-info' => 'Imsurritn n $1 s $2',
'previousrevision' => 'Iẓṛi daɣ aqbur',
'nextrevision' => 'Amẓr amaynu',
'currentrevisionlink' => 'Amcggr amggaṛu',
'cur' => 'Ɣilad',
'next' => 'Imal (wad yuckan)',
'last' => 'Amzwaru',
'page_first' => 'walli izwarn',
'page_last' => 'walli igran',
'histlegend' => 'Isisfiw amzyan : ({{MediaWiki:Cur}}) = urtga zund  lqm (la version) n ɣila, ({{MediaWiki:Last}}) = urd tmcacka d lqm lli izrin, <b>m</b> = ambddl idrusn',
'history-fieldset-title' => 'Sigel ɣ umzruy',
'history-show-deleted' => 'Tḥiyd hlli',
'histfirst' => 'Amzwaru',
'histlast' => 'Amggaru',
'historyempty' => '(orgiss walo)',

# Revision feed
'history-feed-item-nocomment' => '$1 ar $2',

# Revision deletion
'rev-delundel' => 'Mel/ĥbu',
'rev-showdeleted' => 'Mel',
'revdelete-show-file-submit' => 'yah',
'revdelete-radio-set' => 'yah',
'revdelete-radio-unset' => 'uhu',
'revdelete-suppress' => 'Ḥbu issfkatn ḥtta iy-indbal',
'revdelete-unsuppress' => 'Kkiss iqqntn i imcggrn llid n surri.',
'revdelete-log' => 'Maɣ..acku:',
'revdel-restore' => 'sbadl tannayt',
'revdel-restore-deleted' => 'Imsurritn lli ttuykkasnin',
'revdel-restore-visible' => 'Imsurritn lli baynnin',
'pagehist' => 'Amzruy n tasna',
'deletedhist' => 'Amzruy lli ittuykkasn',

# History merging
'mergehistory' => 'Smun imzruyn n tisniwin.',
'mergehistory-header' => 'Tasna yad ar ttjja ad tsmunt ticggarin n umzruy ɣ yat tasna taɣbalut s yat tasna tamaynut.',
'mergehistory-box' => 'Smun ilqqmn ad n snat tisniwin :',
'mergehistory-from' => 'Nasna n uɣbalu.',
'mergehistory-into' => 'Tasna n uwttas:',
'mergehistory-list' => 'Amzruy n imbddln lli munin.',
'mergehistory-merge' => 'ilqqmn ad n [[:$1]] ẓḍarn ad mun d [[:$2]]. Skr s Tannalt n tagffalt (tajrrayt) radyu bac ad tsmunt ilqqmn lli ittuyskarn ɣ umzwaru ar asakud lli ɣin illan. Han ad  tamskart n isdayn n ummuddu rad daɣ alsn z sizwar tannalt ad.',
'mergehistory-go' => 'Ẓṛ imbddln lli izḍarn ad mun.',
'mergehistory-submit' => 'Smun ilqqmn.',
'mergehistory-empty' => 'Ḥtta kra n ulqm ur izḍar ad imun ɣ wayya.',
'mergehistory-success' => '$3 lqm{{PLURAL:$3||s}} n [[:$1]]  {{PLURAL:$3|imunn|munnin}} ɣ [[:$2]].',
'mergehistory-fail' => 'Ur as yuffi ad yili umun ɣ yan n imzruyn. Sti daɣ tasna d ḥtta iɣwwarn n usakud.',
'mergehistory-no-source' => 'Tasna taɣbalut $1 ur tlli.',
'mergehistory-no-destination' => 'Tasna n uwttas $1 ur tlli.',
'mergehistory-invalid-source' => 'Tasna taɣbalut ila fllas ad tili yan uzwl lli igaddan.',
'mergehistory-invalid-destination' => 'Tasna n uwttas illa fllas ad ṭṭaf yan uzwl igaddan.',
'mergehistory-autocomment' => '[[:$1]] tllan ɣ ugns n  [[:$2]]',
'mergehistory-comment' => 'Tllan [[:$1]] ɣ ugns n  [[:$2]]: $3',
'mergehistory-same-destination' => 'Tisniwin tiɣbula d tin ɣilli rant urgant yat.',
'mergehistory-reason' => 'Maɣ:',

# Merge log
'mergelog' => 'Aɣmis n imsmun',
'pagemerge-logentry' => '[[$1]] tllan ɣ  [[$2]] (Lqm ar $3)',
'revertmerge' => 'Fukku',
'mergelogpagetext' => 'Γid umuɣ n izdayn n umzruy n yat tasna ɣ yat yaḍn lli igan tamaynut',

# Diffs
'history-title' => 'Asakud n umcggr n « $1 »',
'difference-multipage' => 'Amzaray (laḥna) gr tisniwin',
'lineno' => 'Izriri $1:',
'compareselectedversions' => 'Snahya gr ilqmn lli tuystaynin',
'showhideselectedversions' => 'Ml/Ḥbu ilqmn lli ittuystayn',
'editundo' => 'Urri',
'diff-multi' => '({{PLURAL:$1|yan ulqm gratsn|$1 ilqmn gratsn}} z {{PLURAL:$2|umqdac|$2 imqdacn}} {{PLURAL:$1|iḥba|ḥban}})',
'diff-multi-manyusers' => '({{PLURAL:$1|yan ulqm n gratsn|$1 ilqmn ngratsn}} zdar mnnaw {{PLURAL:$2|amcgr |n $2 imcgrn}} {{PLURAL:$1|iḥba|lli iḥban}})',

# Search results
'searchresults' => 'Mad akkan icnubcn',
'searchresults-title' => 'Mad akkan icnubcn f "$1"',
'searchresulttext' => 'Inɣmisn yaḍnin f {{SITENAME}},  ẓr  [[{{MediaWiki:Helppage}}|{{int:help}}]].',
'searchsubtitle' => 'Ar tsiggilt f \'\'\'[[:$1]]\'\'\' ([[Special:Prefixindex/$1|tisniwin li kullu ttiswirnin s "$1"]]{{int:pipe-separator}}[[Special:WhatLinksHere/$1|tisniwin li kullu ttiswirnin s "$1"]])',
'searchsubtitleinvalid' => "Tsiggelt  '''$1'''",
'toomanymatches' => 'Illa bzzaf maygan zund maya. sbadl taguri yad skra yaḍn',
'titlematches' => 'Assaɣ n tasna iga zund',
'notitlematches' => 'Ur ityuffa kra ntansa zund ɣwad',
'textmatches' => 'Aṭṛiṣ n tasna iga zund',
'notextmatches' => 'Ur ittyufa kra nu uṭṛiṣ igan zund ɣwad',
'prevn' => 'Tamzwarut {{PLURAL:$1|$1}}',
'nextn' => 'Tallid yuckan {{PLURAL:$1|$1}}',
'prevn-title' => '$1 {{PLURAL:$1|Askfa amzaru|Iskfatn imzwura}}',
'nextn-title' => '$1 {{PLURAL:$1|askfa d itfrn|iskfatn d itfrn}}',
'shown-title' => 'Fsr $1 tayafut{{PLURAL:$1||s}} s tasna',
'viewprevnext' => 'Mel ($1 {{int:pipe-separator}} $2) ($3)',
'searchmenu-legend' => 'Istayn ucnubc',
'searchmenu-exists' => '"\'Tlla yat tasna lli ilan assaɣ « [[:$1]] » ɣ wiki yad',
'searchmenu-new' => "'''Skr Tasna « [[:$1|$1]] » ɣ wiki !'''",
'searchhelp-url' => 'Help:Mayllan',
'searchprofile-articles' => 'Mayllan ɣ tasna',
'searchprofile-project' => 'Tisniwin n w-aws n usnfar',
'searchprofile-images' => 'Multimedia',
'searchprofile-everything' => 'kullu',
'searchprofile-advanced' => 'motaqqadim',
'searchprofile-articles-tooltip' => 'qlb gh $1',
'searchprofile-project-tooltip' => 'qlb gh $1',
'searchprofile-images-tooltip' => 'qlb gh tswira',
'searchprofile-everything-tooltip' => 'Cabba ɣ kullu may ityran ɣid (d ḥtta ɣ tisna nu umsgdal)',
'searchprofile-advanced-tooltip' => 'Cabba ɣ igmmaḍn li tuyzlaynin',
'search-result-size' => '$1 ({{PLURAL:$2|1 taguri|$2 tiguriwin}})',
'search-result-category-size' => '$1 amdan{{PLURAL:$1||i-n}} ($2 ddu talɣa{{PLURAL:$2||i-s}}, $3 asdaw{{PLURAL:$3||i-n}})',
'search-result-score' => 'Tazdayt: $1%',
'search-redirect' => '(Asmmati $1)',
'search-section' => 'Ayyaw $1',
'search-suggest' => 'Is trit att nnit: $1',
'search-interwiki-caption' => 'Tiwuriwin taytmatin',
'search-interwiki-default' => '$1 imyakkatn',
'search-interwiki-more' => '(Uggar)',
'search-relatedarticle' => 'Tzdi',
'mwsuggest-disable' => 'Asbid AJAX n maryttuynnan ayttuyskar',
'searcheverything-enable' => 'Cabba ɣ graygat agmmaḍ',
'searchrelated' => 'Tuyzday',
'searchall' => 'Kullu',
'showingresults' => "Ẓr azddar  {{PLURAL:$1|'''1''' May tuykfan|'''$1''' Mad kfan}} Bdu s #'''$2'''",
'showingresultsnum' => "Ẓr azddar (ifsr ɣ uzddar) {{PLURAL:$3|'''1''' may kfa|'''$3''' mad kfan}} Bdu s #'''$2'''.",
'showingresultsheader' => "{{PLURAL:$5|May kfa '''$1''' ar '''$3'''|Mad kfan '''$1 - $2''' ar '''$3'''}} i '''$4'''",
'nonefound' => "'''Arra''': Icnubbu ar tilin ɣir tiɣulin tuyzlaynin. Iɣ trit at cabbat ɣ kullu may tyuran d ḥtta tisnatin nu umsgdal s ''all:'', bdu acnubc  nek s kullu ma ɣɣid imun, ulla s assaɣ n tɣult li trit.",
'search-nonefound' => 'Ur ittuykfa walu maygan zund ɣayli trit',
'powersearch' => 'Amsigl imzwarn',
'powersearch-legend' => 'Amsigl imzwarn',
'powersearch-ns' => 'Icnubbucn ɣ tɣulin',
'powersearch-redir' => 'Afsr n ismmatayn (Tifilit n ismmatayn)',
'powersearch-field' => 'Acnubc ɣ',
'powersearch-togglelabel' => 'Sti',
'powersearch-toggleall' => 'Kullu',
'powersearch-togglenone' => 'Walu',
'search-external' => 'Acnubc b brra',
'searchdisabled' => '{{SITENAME}} Acnubc ibid.
Tzdar at cabbat ɣilad ɣ Google.
Izdar ad urtili ɣ isbidn n mayllan ɣ {{SITENAME}} .',

# Quickbar
'qbsettings' => 'Tafeggagt izrbn',
'qbsettings-none' => 'Ur iḥudda',
'qbsettings-fixedleft' => 'Aẓẓugz azlmaḍ',
'qbsettings-fixedright' => 'Azzugz afasi',
'qbsettings-floatingleft' => 'Yaywul su uzlmad',
'qbsettings-floatingright' => 'Yaywul su ufasi',

# Preferences page
'preferences' => 'Timssusmin',
'mypreferences' => 'Timssusmin',
'prefs-edits' => 'Uṭṭun n n imbddeln',
'prefsnologin' => 'Ur tmlit mat git',
'changepassword' => 'bdl awal ihdan',
'prefs-skin' => 'odm',
'skin-preview' => 'Ammal',
'datedefault' => 'Timssusmin',
'prefs-datetime' => 'waqt d tarikh',
'prefs-personal' => 'milf n umsxdam',
'prefs-rc' => 'Imbddeln imggura',
'prefs-watchlist' => 'lista n tabiaa',
'prefs-watchlist-days' => 'osfan liratzrt gh lista n umdfur',
'prefs-watchlist-days-max' => 'Maximum $1 {{PLURAL:$1|day|days}}',
'prefs-watchlist-token' => 'tasarut n list n omdfor',
'prefs-misc' => 'motafarriqat',
'prefs-resetpass' => 'bdl awal ihdan',
'prefs-email' => 'lkhiyarat n Email',
'prefs-rendering' => 'adm',
'saveprefs' => 'sjjl',
'resetprefs' => 'hiyd tghyirat li orsjilnin',
'restoreprefs' => 'sglbd kollo regalega',
'prefs-editing' => 'tahrir',
'prefs-edit-boxsize' => 'hajm nafida n thrir',
'rows' => 'sfof:',
'columns' => 'aamida:',
'searchresultshead' => 'Cabba',
'resultsperpage' => 'adad nataij gh sfha:',
'stub-threshold' => 'wasla n  <a href="#" class="stub">do amzdoy</a> itforma (bytes):',
'stub-threshold-disabled' => 'moattal',
'recentchangesdays' => 'adad liyam lmroda gh ahdat tghyirat',
'localtime' => '↓Tizi n ugmaḍ ad:',
'servertime' => 'Asaru n Tizi',
'guesstimezone' => 'skchm twqit gh lmotasaffih',
'timezoneregion-africa' => 'Africa',
'timezoneregion-america' => 'America',
'timezoneregion-antarctica' => 'Antarctica',
'timezoneregion-arctic' => 'Arctic',
'timezoneregion-asia' => 'Asia',
'timezoneregion-atlantic' => 'Atlantic Ocean',
'timezoneregion-australia' => 'Australia',
'timezoneregion-europe' => 'Europa',
'timezoneregion-indian' => 'Indian Ocean',
'timezoneregion-pacific' => 'Pacific Ocean',
'allowemail' => 'artamz limail dar isxdamn yadni',
'prefs-searchoptions' => 'Istayn ucnubc',
'prefs-namespaces' => 'Ismawn n tɣula',
'defaultns' => 'ghd sigl gh nitaqat ad',
'default' => 'iftiradi',
'prefs-files' => 'Asdaw',
'prefs-custom-css' => 'khss CSS',
'prefs-custom-js' => 'khss JavaScipt',
'youremail' => 'Tabrat mail',
'username' => 'smiyt o-msxdam:',
'uid' => 'raqm omskhdam:',
'prefs-registration' => 'waqt n tsjil:',
'yourrealname' => 'smiyt nk lmqol',
'yourlanguage' => 'tutlayt:',
'yournick' => 'sinyator',
'yourgender' => 'ljins',
'gender-unknown' => 'ghayr mohdad',
'gender-male' => 'dkr',
'gender-female' => 'lont',
'email' => 'email',
'prefs-help-email' => 'Tansa n tbratin ur tga bzzez, mac trwa ad taft taguri n uzray d ar ak tskar ast tsbadlt iɣ tti tuut.',
'prefs-help-email-others' => 'Tẓḍart ad tstit ad tajt wiyyaḍ ad ak ttaran, snḥkmn dik ɣ, mlinak iwnnan nsn ɣ tasna lli sik iẓlin bla ssn assaɣ nk d mad tgit.',
'prefs-signature' => 'sinyator',
'prefs-dateformat' => 'sight n loqt',

# Groups
'group-sysop' => 'Anedbalen n unagraw',

'grouppage-sysop' => '{{ns:project}}: Inedbalen',

# Special:Log/newusers
'newuserlogpage' => 'Aɣmis n willi mmurzmn imiḍan amsqdac',

# User rights log
'rightslog' => 'Anɣmas n imbddlnn izrfan n umsqdac',

# Associated actions - in the sentence "You do not have permission to X"
'action-read' => 'Ssɣr tasna yad',
'action-edit' => 'Ẓrig tasna yad.',
'action-createpage' => 'Snufl tasna yad. (gttin)',
'action-createtalk' => 'Snufl Tisniwin ad. (xlqtnt)',
'action-createaccount' => 'snulf amiḍan ad n usqdac',

# Recent changes
'nchanges' => '$1 imbddln {{PLURAL:$1||s}}',
'recentchanges' => 'Imbddeln imggura',
'recentchanges-legend' => 'Tixtiɣitin (options) n imbddl imaynutn',
'recentchanges-summary' => 'Ml imbddln imaynutn  n wiki ɣ tasna yad',
'recentchanges-feed-description' => 'Tfr imbddln imggura n wiki yad ɣ usuddm',
'recentchanges-label-newpage' => 'Ambddl ad ar iskar yakka yat tasna tamaynut.',
'recentchanges-label-minor' => 'Imbddl ifssusn',
'recentchanges-label-bot' => 'Ambddl ad iskr robot',
'recentchanges-label-unpatrolled' => 'Ambddl ad ura jju ittmẓra',
'rcnote' => 'Γid {{PLURAL:$1|ambddl amggaru lli ittuysgarn| $1 Imbddln imggura lli ittuyskarn}} ɣ {{PLURAL:$2|was amggaru| <b>$2</b> Ussan imggura}} ar $5 n $4.',
'rcnotefrom' => "Had imbddln lli ittuyskarn z '''$2''' ('''$1''' ɣ uggar).",
'rclistfrom' => 'Mel imbdeltn imaynutn z $1',
'rcshowhideminor' => '$1 iẓṛign fssusnin',
'rcshowhidebots' => '$1 butn',
'rcshowhideliu' => '$1 midn li ttuyqqiyadnin',
'rcshowhideanons' => '$1 midn ur ttuyssan nin',
'rcshowhidepatr' => '$1 Imbddln n tsagga',
'rcshowhidemine' => '$1 iẓṛign inu',
'rclinks' => 'Ml id  $1 n imbddltn immgura li ittuyskarn n id $2 ussan ad gguranin<br />$3.',
'diff' => 'Gar',
'hist' => 'Amzruy',
'hide' => 'Ḥbu',
'show' => 'Mel',
'minoreditletter' => 'm',
'newpageletter' => 'A',
'boteditletter' => 'q',
'unpatrolledletter' => '!',
'number_of_watching_users_pageview' => '[$1 iżŗi {{PLURAL:$1|amsqdac|imsqdacn}}]',
'rc_categories_any' => 'wanna',
'rc-change-size' => '$1',
'newsectionsummary' => '/* $1 */ ayaw amaynu',
'rc-enhanced-expand' => 'Ml ifruriyn (ira JavaScript)',
'rc-enhanced-hide' => 'Ĥbu ifruriyn',

# Recent changes linked
'recentchangeslinked' => 'Imbddel zun ɣwid',
'recentchangeslinked-feed' => 'Imbddeln zund ɣwid',
'recentchangeslinked-toolbox' => 'Imbddeln zund ɣwid',
'recentchangeslinked-title' => 'Imbddeln li izdin "$1"',
'recentchangeslinked-noresult' => 'Ur illi may budeln ɣ tisniwin li dar izdayn s ɣid',
'recentchangeslinked-summary' => 'Ɣid umuɣ iymbddeln li ittyskarnin tigira yad ɣ tisniwin li ittuyzdayn d kra n tasna (ulla i igmamn n kra taggayt ittuyzlayn). Tisniwin  ɣ [[Special:Watchlist|Umuɣ n tisniwin li ttsaggat]].',
'recentchangeslinked-page' => 'Assaɣ n tasna',
'recentchangeslinked-to' => 'Afficher les changements vers les pages liées au lieu de la page donnée
Mel imbddeln z tisniwin li ittuyzdayni bla tasna li trit.',

# Upload
'upload' => 'Srbu asddaw',
'uploadbtn' => 'Srbu asddaw',
'reuploaddesc' => 'Sbidd asrbu d turrit',
'upload-tryagain' => 'Ṣafḍ Anglam n ufaylu li ibudln',
'uploadnologin' => 'Ur tmlit mat git',
'uploadnologintext' => 'Mel zwar mat git [[Special:UserLogin|Mel mat git]] iɣ trit ad tsrbut isddawn.',
'upload_directory_missing' => 'Akaram n w-affay ($1) ur ittyufa d urt iskr uqadac web (serveur)',
'uploadlogpage' => 'Anɣmis n isrbuṭn',
'filename' => 'Assaɣ n usdaw',
'filedesc' => 'Talusi',
'fileuploadsummary' => 'Talusi',
'filereuploadsummary' => 'Imbddln n usdaw',
'filestatus' => 'Izrfan ḥbanin',
'filesource' => 'Aɣbalu',
'uploadedimage' => 'Issrba "[[$1]]"',
'upload-source' => 'Aɣbalu n usdaw',
'sourcefilename' => 'Aɣbalu n ussaɣ n usdaw',

'license' => 'Tlla s izrfan',
'license-header' => 'Tẓrg ddu n izrfan',

# File description page
'file-anchor-link' => 'Asdaw',
'filehist' => 'Amzry n usdaw',
'filehist-help' => 'Adr i asakud/tizi bac attżrt manik as izwar usddaw ɣ tizi yad',
'filehist-revert' => 'Sgadda daɣ',
'filehist-current' => 'Ɣilad',
'filehist-datetime' => 'Asakud/Tizi',
'filehist-thumb' => 'Awlaf imżżin',
'filehist-thumbtext' => 'Mżżi n lqim ɣ tizi $1',
'filehist-user' => 'Amsqdac',
'filehist-dimensions' => 'Dimensions',
'filehist-comment' => 'Aɣfawal',
'imagelinks' => 'Izdayn n usdaw',
'linkstoimage' => 'Tasna yad {{PLURAL:$1|izdayn n tasna|$1 azday n tasniwin}} s usdaw:',
'nolinkstoimage' => 'Ḥtta kra n tasna ur tra asdaw ad',
'sharedupload' => 'Asdawad z $1 tẓḍart at tsxdmt gr iswirn yaḍnin',
'sharedupload-desc-here' => 'ⴰⵙⴷⴰⵡ ⴰⴷ ⵉⴽⴽⴰⴷ ⵣ : $1.  ⵜⵥⴹⴰⵔⵜ ⴰⵙⵙⵉ ⵜⵙⵡⵡⵓⵔ ⵖ ⵜⵉⵡⵓⵔⵉⵡⵉⵏ ⵜⴰⴹⵏ.
ⵓⴳⴳⴰⵔ ⴼⵍⵍⴰⵙ ⵍⵍⴰⵏ ⵖ [$2 ⵜⴰⵙⵏⴰ ⵏ ⵉⵎⵍⵓⵣⵣⵓⵜⵏ] ⵍⵍⵉ ⵉⵍⵍⴰⵏ ⵖⵉⴷ.',
'uploadnewversion-linktext' => 'Srbud tunɣilt tamaynut n usdaw ad',

# Random page
'randompage' => 'Tasna s zhr (ⵜⴰⵙⵏⴰ ⵙ ⵣⵀⵔ)',

# Statistics
'statistics' => 'Tisnaddanin',

'disambiguationspage' => 'Template:Homonymie',

# Miscellaneous special pages
'nbytes' => '$1 {{PLURAL:$1|byt|byt}}',
'ncategories' => '$1 {{PLURAL:$1|taggayt|taggayin}}',
'nlinks' => '$1 {{PLURAL:$1|azday|izdayn}}',
'nmembers' => '$1 {{PLURAL:$1|agmam|igmamn}}',
'nrevisions' => '$1 {{PLURAL:$1|asgadda|isgaddatn}}',
'nviews' => '$1 {{PLURAL:$1|assag|issagn}}',
'specialpage-empty' => 'Ur illa mayttukfan i asaggu yad',
'lonelypages' => 'Tasnatiwin tigigilin',
'lonelypagestext' => 'Tisnawinad ur ur tuyzdaynt z ulla lant ɣ tisniwin yaḍnin ɣ {{SITENAME}}.',
'uncategorizedpages' => 'Tisnawinad ur llant ɣ graygan taggayt',
'uncategorizedcategories' => 'Taggayin ur ittuyzlayn ɣ kraygan taggayt',
'prefixindex' => 'Tisniwin lli izwarn s ...',
'usercreated' => '{{GENDER:$3|tuyskar}}  z $1 ar $2',
'newpages' => 'Tisniwin timaynutin',
'move' => 'Smmatti',
'movethispage' => 'Smmatti tasna yad',
'unusedcategoriestext' => 'Taggayin ad llant waxxa gis nt ur tlli kra n tasna wala kra n taggayin yaḍnin',
'notargettitle' => 'F walu',
'nopagetext' => 'Tasna li trit ur tlli',
'pager-newer-n' => '{{PLURAL:$1|amaynu 1|amaynu $1}}',
'pager-older-n' => '{{PLURAL:$1|aqbur 1|aqbur $1}}',
'suppress' => 'Iẓriyattuyn',

# Book sources
'booksources' => 'Iɣbula n udlis',
'booksources-search-legend' => 'Acnubc s iɣbula n idlisn',
'booksources-isbn' => 'ISBN:',
'booksources-go' => 'Ftu',

# Special:Log
'specialloguserlabel' => 'Amsqdac',
'speciallogtitlelabel' => 'Azwl',
'log' => 'Immussutn ittyuran',
'all-logs-page' => 'Immussutn ittyuran immurzmn i kullu..',
'log-title-wildcard' => 'Cabba s iswln li ttizwirnin s uṭṛiṣ ad',

# Special:AllPages
'allpages' => 'Tisniwin kullu tnt',
'alphaindexline' => '$1 ar $2',
'nextpage' => 'Tasna li rad yack ($1)',
'prevpage' => 'Tasna li izrin $1',
'allpagesfrom' => 'Mel tisniwin li ittizwirn z',
'allpagesto' => 'Mel tasniwin li ttgurunin s',
'allarticles' => 'Tasniwin kullu tnt',
'allinnamespace' => 'Tasniwin kullu tnt ɣ ($1 assaɣadɣar)',
'allnotinnamespace' => 'Tasniwin kullu tnt ur llant ɣ ($1 assaɣadɣar)',
'allpagesprev' => 'Amzwaru (walli izwarn)',
'allpagesnext' => 'Imal (wad yuckan)',
'allpagessubmit' => 'Ftu',
'allpagesprefix' => 'Mel tasniwin li ttizwirnin s',

# Special:Categories
'categories' => 'imggrad',

# Special:LinkSearch
'linksearch' => 'Izdayn n brra',
'linksearch-line' => '$1 tmmuttid z $2',

# Special:ListGroupRights
'listgrouprights-members' => 'Umuɣ n  midn',

# Email user
'emailuser' => 'Azn tabrat umsqdac ad',

# Watchlist
'watchlist' => 'Umuɣ n imtfrn',
'mywatchlist' => 'Umuɣ inu lli tsaggaɣ',
'watchlistfor2' => 'I $1 $2',
'addedwatchtext' => 'tasna « [[:$1]] » tllan ɣ [[Special:Watchlist|umuɣ n umtfr]]. Imbdln lli dyuckan d tasna lli dis iṭṭuzn rad asn nskr agmmaḍ nsn. Tasna radd ttbayan s "uḍnay" ɣ [[Special:RecentChanges|Umuɣ n imbddeln imaynutn]]',
'removedwatchtext' => 'Tasna "[[:$1]]" ḥra ttuykkas z [[Special:Watchlist|your watchlist]].',
'watch' => 'zaydtin i tochwafin-niw',
'watchthispage' => 'Ṭfr tasna yad',
'unwatch' => 'Ur rast tsaggaɣ',
'watchlist-details' => 'Umuɣ nk n imttfura ar  ittawi $1 tasna {{PLURAL:$1||s}}, bla dis tsmunt tisniwin n imdiwiln.',
'wlshowlast' => 'Ml ikudan imggura $1 , ussan imggura $2 niɣd $3',
'watchlist-options' => 'Tixtiṛiyin n umuɣ lli ntfar',

# Displayed when you click the "watch" button and it is in the process of watching
'watching' => 'Ar itt sagga',
'unwatching' => 'Ur at sul ntsagga',

# Delete
'deletepage' => 'Amḥiyd n tasna',
'confirmdeletetext' => 'Ḥan tbidt f attkkist tasna yad kullu d kullu amzruy nes.
illa fllak ad ni tẓrt is trit ast tkkist d is tssnt marad igguṛu iɣt tkkist d is iffaɣ mayad i [[{{MediaWiki:Policy-url}}|tasrtit]].',
'actioncomplete' => 'tigawt tummidt',
'actionfailed' => 'Tawwuri i xsrn',
'deletedtext' => '"$1"  ttuykkas.
Ẓṛ $2 inɣmas imggura n ma ittuykkasn',
'dellogpage' => 'Qqiyd akkas ad',
'deletecomment' => '! Maɣ:',
'deleteotherreason' => 'Wayyaḍ/ maf ittuykkas yaḍn',
'deletereasonotherlist' => 'Maf ittuykkas yaḍn',

# Rollback
'rollbacklink' => 'Rard',

# Protect
'protectlogpage' => 'Iɣmisn n ugdal',
'protectedarticle' => 'ay gdl  "[[$1]]"',
'modifiedarticleprotection' => 'isbudl taskfalt n ugdal n « [[$1]] »',
'protectcomment' => 'Maɣ:',
'protectexpiry' => 'Tizi nu uzri n umzruy:',
'protect_expiry_invalid' => 'Tizi n uzri n umzruy urtti tga.',
'protect_expiry_old' => 'Tizi n uzri n umzruy n zrit.',
'protect-text' => "Tzḍaṛt ad tẓṛt niɣ tbudlt taskflt n ugdal (protection) n tasna '''$1'''.",
'protect-locked-access' => "Ur tẓdart wala ittuyskarak ad tbadlt tiskfal n ugdal n tisniwin.
Ha riglaj n ɣila lli f tlla tasna '''$1''' :",
'protect-cascadeon' => 'Tasna yad tgddl (protégé) t llan ɣ {{PLURAL:$1|Tasna llid yuckan, talli igddln| Tillid yuckan, lli igddln}} s tamatart ad « Agdl s imuzzar ». Tzḍart ad tsbadlt iswirn n ugdlns bla irza mayad aǧdl s imuzzar',
'protect-default' => 'Immurzm i kullu imsxdamn',
'protect-fallback' => 'Tra "$1" ajja (permission)',
'protect-level-autoconfirmed' => 'Sbid tqqnt f imsqdacn imaynutn lli ur ittuyssanin',
'protect-level-sysop' => 'Imɣarn ṣafi.',
'protect-summary-cascade' => 'Agdal n imuzzar',
'protect-expiring' => 'tzri $1 (UTC)',
'protect-cascade' => 'gdlnt wala tisniwin llin illan ɣ tasna yad (Agdal s imuzzar)',
'protect-cantedit' => 'Ur as tufit ad sbadlt tiskfal n ugdal n tasna yad acku urak ittuyskar',
'restriction-type' => 'Turagt',
'restriction-level' => 'Restriction level:',

# Undelete
'undeletelink' => 'mel/rard',
'undeleteviewlink' => 'Ẓṛ',

# Namespace form on various pages
'namespace' => 'Taɣult',
'invert' => 'amglb n ustay',
'blanknamespace' => '(Amuqran)',

# Contributions
'contributions' => 'Tiwuriwin n umsaws',
'contributions-title' => 'Umuɣ n tiwuriwin n umsqdac $1',
'mycontris' => 'Tiwuriwin inu',
'contribsub2' => 'I $1 ($2)',
'uctop' => '(tamgarut)',
'month' => 'Z usggas (d urbur):',
'year' => 'Z usggas (d urbur):',

'sp-contributions-newbies' => 'Ad ur tmlt abla tiwuriwin n wiyyaḍ',
'sp-contributions-newbies-sub' => 'Z imiḍan (comptes) imaynutn',
'sp-contributions-newbies-title' => 'Tiwuriwin n umqdac z imḍan imaynutn',
'sp-contributions-blocklog' => 'Tinɣmas n willi ttuyqqanin (blocage)',
'sp-contributions-deleted' => 'Tiwuriwin lli ittuykkasnin',
'sp-contributions-uploads' => 'Iwidn',
'sp-contributions-logs' => 'Iɣmisn',
'sp-contributions-talk' => 'Sgdl (discuter)',
'sp-contributions-userrights' => 'Sgiddi izrfan',
'sp-contributions-blocked-notice' => 'Amsqdac ad ittuysbddad. Maf ittuysbddad illa ɣ uɣmmis n n willi n sbid. Mayad ɣ trit ad tsnt maɣ',
'sp-contributions-blocked-notice-anon' => 'Tansa yad IP ttuysbddad. Maf ittuysbddad illa ɣ uɣmmis n n willi n sbid. Mayad ɣ trit ad tsnt maɣ',
'sp-contributions-search' => 'Cnubc f tiwuriwin',
'sp-contributions-username' => 'Tansa IP niɣ assaɣ nu umsqdac:',
'sp-contributions-toponly' => 'Ad urtmlt adla mat ittuyẓran tigira yad',
'sp-contributions-submit' => 'Cabba (Sigl)',
'sp-contributions-explain' => '↓',

# What links here
'whatlinkshere' => 'May izdayn ɣid',
'whatlinkshere-title' => 'Tisniwin li izdayn d "$1"',
'whatlinkshere-page' => 'Tasna:',
'linkshere' => "Tasnawinad ar slkamnt i '''[[:$1]]''':",
'nolinkshere' => "Ur llant tasniwin li izdin d '''[[:$1]]'''.",
'nolinkshere-ns' => "Ur tlla kra n tasna izdin d  '''[[:$1]]''' ɣ tɣult l-ittuystayn.",
'isredirect' => 'Tasna immutin',
'istemplate' => 'Illa gis',
'isimage' => 'Azday s usdaw',
'whatlinkshere-prev' => '{{PLURAL:$1|amzwaru|amzwaru $1}}',
'whatlinkshere-next' => '{{PLURAL:$1|wali d yuckan|wali d yuckan $1}}',
'whatlinkshere-links' => '← izdayn',
'whatlinkshere-hideredirs' => '$1 Ismmattayn',
'whatlinkshere-hidetrans' => '$1 mayllan gis',
'whatlinkshere-hidelinks' => '$1 izdayn',
'whatlinkshere-hideimages' => '$1 izdayn awlaf',
'whatlinkshere-filters' => 'Istayn',

# Block/unblock
'blockip' => 'Qn f umsqdac',
'ipboptions' => '2 ikudn:2 hours,1 as:1 day,3 ussan:3 days,1 imalas:1 week,2 imalasn:2 weeks,1 ayur:1 month,3 irn:3 months,6 irn:6 months,1 asggas:1 year,tusut ur iswuttan:infinite',
'ipbotheroption' => 'wayya',
'ipbhidename' => 'ḥbu assaɣ n umsqdac ɣ imbdln d umuɣn',
'ipbwatchuser' => 'Tfr tisniwin d imsgdaln n umqdac',
'ipblocklist' => 'Imsqdacn ttuẓnin',
'blocklink' => 'Adur tajt',
'unblocklink' => 'kkis agdal',
'change-blocklink' => 'Sbadl agdal',
'contribslink' => 'tikkin',
'blocklogpage' => 'aɣmmis n may ittuyqqanin',
'blocklog-showlog' => 'Amsqdac ikkattin ittuyqqan. anɣmis n willi ttuyqqanin  ɣid:',
'blocklog-showsuppresslog' => 'Amsqdac ikkattin ittuyqqan d iḥba. Anɣmis n willi ttuyqqanin  ɣid:',
'blocklogentry' => 'tqn [[$1]] s tizi izrin n $2 $3',
'unblocklogentry' => 'immurzm $1',
'block-log-flags-nocreate' => 'Ammurzm n umiḍan urak ittuyskar',

# Move page
'movepagetext' => "Swwur s tifrkkitad bac ad sbadlt uzwl tasna yad , s usmmattay n umzru ns s uzwl amaynu . Assaɣ Aqbur rad ig ɣil yan usmmattay n tasna s uzwl (titre) amynu . Tâḍart ad s tgt immattayn n ɣil f was fwas utumatik s dar uswl amaynu.  Iɣ tstit bac ad tskrt . han ad ur ttut ad tẓrt kullu  [[Special:DoubleRedirects|double redirection]] ou [[Special:BrokenRedirects|redirection cassée]]. Illa fllak ad ur ttut masd izdayn rad tmattayn s sin igmmaḍn ur igan yan.

Smmem masd tasna ur rad tmmatti iɣ tlla kra n yat yaḍn lli ilan asw zund nttat . Abla ɣ dars amzruy ɣ ur illa umay,  nɣd yan usmmattay ifssusn. 

''' Han !'''
Maya Iẓḍar ad iglb zzu uzddar ar aflla tasna yad lli bdda n nttagga. Illa fllak ad urtskr mara yigriẓ midn d kiyyin lli iswurn ɣ tasna yad. issin mara tskr urta titskrt..",
'movepagetalktext' => "Tasna n umsgdal (imdiwiln) lli izdin d ɣta iɣ tlla, rad as ibadl w-assaɣ utumatik  '''abla iɣ :'''
* tsmmuttim tasna s yan ugmmaḍ wassaɣ, niɣd
* tasna n umsgdal( imdiwiln) tlla s wassaɣ ad amaynu, niɣd
* iɣ tkrjm tasatmt ad n uzddar

Γ Tiklayad illa flla tun ad tsbadlm assaɣ niɣt tsmun mayad s ufus ɣ yat, iɣ tram",
'movearticle' => 'Smmatti tasna niɣ as tsbudlt assaɣ',
'newtitle' => 'dar w-assaɣ amaynu:',
'move-watch' => 'Tfr tisniwin timaynutin d timẓlay',
'movepagebtn' => 'Smmatti tasna niɣ as tsbudlt assaɣ',
'pagemovedsub' => 'tmmutti bla tamukrist',
'movepage-moved' => '\'\'\'"$1" tmmutti s "$2"\'\'\'',
'articleexists' => 'Tlla yad tasna illan assaɣ zund ɣwa niɣd assaɣ llid tiwid urt iga. Sti assaɣ yaḍn tarmt.',
'talkexists' => 'Tasna tmmutti mzyan, mac tasna n umsgdal (imdiwiln) ur tmmutti acku tlla f wassaɣ ad amaynu.Illa fllak aggisnt tskrt yat s ufus nk.',
'movedto' => 'Tmmuti s',
'movetalk' => 'Sbadl assaɣ tasna n imdiwiln lli izdin d ɣi.',
'movelogpage' => 'Iɣmisn n ismmattrayn',
'movelogpagetext' => 'Γid umuɣ n tisniwin lli sbadlnin assaɣ d tilli mmuttini.',
'movesubpage' => 'Ddu-tasna {{PLURAL:$1||s}}',
'movereason' => 'Maɣ:',
'revertmove' => 'Rard',

# Export
'export' => 'assufɣ n tasniwin',

# Namespace 8 related
'allmessagesname' => 'Assaɣ',
'allmessagesdefault' => 'Tabrat bla astay',

# Thumbnails
'thumbnail-more' => 'Simɣur',
'thumbnail_error' => 'Irrur n uskr n umssutl: $1',

# Tooltip help for the actions
'tooltip-pt-userpage' => 'Tasna n umsqdac',
'tooltip-pt-mytalk' => 'Tasnat umsgdal inu',
'tooltip-pt-anontalk' => 'Amsgdal f imbddeln n tansa n IP yad',
'tooltip-pt-preferences' => 'Timssusmin inu',
'tooltip-pt-watchlist' => 'Tifilit n tisnatin li itsaggan imdddeln li gisnt ittyskarn..',
'tooltip-pt-mycontris' => 'Tabdart n ismmadn inu',
'tooltip-pt-login' => 'Yufak at qiyt akcum nek, mach ur fllak ibziz .',
'tooltip-pt-anonlogin' => 'Ifulki at tqiyt akcum nek, mac ur fllak iga bziz',
'tooltip-pt-logout' => 'Affuɣ',
'tooltip-ca-talk' => 'Assays f mayllan ɣ tasnat ad',
'tooltip-ca-edit' => 'Tzḍaṛt  at tsbadelt tasna yad. Ifulki iɣt zwar turmt ɣ tasna w-arm',
'tooltip-ca-addsection' => 'Bdu ayyaw amaynu.',
'tooltip-ca-viewsource' => 'Tasnatad tuyḥba. mac dẓdart at tẓrt aɣbalu nes.',
'tooltip-ca-history' => 'Tunɣilt tamzwarut n tasna yad',
'tooltip-ca-protect' => 'Ḥbu tasna yad',
'tooltip-ca-unprotect' => 'Kkis aḥbu n tasna yad',
'tooltip-ca-delete' => 'Kkis tasna yad',
'tooltip-ca-undelete' => 'Rard imbddeln imzwura li ittyskarnin ɣ tasna yad',
'tooltip-ca-move' => 'Smmati tasna yad',
'tooltip-ca-watch' => 'Smd tasna yad itilli tsaggat.',
'tooltip-ca-unwatch' => 'Kkis tasna yad z ɣ tilli tsaggat',
'tooltip-search' => 'siggl ɣ {{SITENAME}}',
'tooltip-search-go' => 'Ftu s tasna s w-assaɣ znd ɣ-wad  iɣ tlla',
'tooltip-search-fulltext' => 'Cnubc aṭṛiṣad ɣ tisnatin',
'tooltip-p-logo' => 'Tasnat tamuqrant',
'tooltip-n-mainpage' => 'Kkid tasna tamzwarut',
'tooltip-n-mainpage-description' => 'Kid tasna tamuqrant',
'tooltip-n-portal' => "f' usenfar, matzdart atitskrt, maniɣrattaft ɣayli trit",
'tooltip-n-currentevents' => 'Tiɣri izrbn i kullu maɣid immusn',
'tooltip-n-recentchanges' => 'Umuɣ n imbddlen imaynuten ɣ l-wiki',
'tooltip-n-randompage' => 'Srbu yat tasna ɣik nna ka tga',
'tooltip-n-help' => 'Adɣar n w-aws',
'tooltip-t-whatlinkshere' => 'Umuɣ n kullu tisnatin n Wiki lid ilkkmn ɣid',
'tooltip-t-recentchangeslinked' => 'Imbddln imaynutn n tisnatin li ittylkamn s tasna yad',
'tooltip-feed-rss' => 'Usuddm (Flux) n tasna yad',
'tooltip-feed-atom' => 'Usuddm Atum n tasna yad',
'tooltip-t-contributions' => 'Ẓr umuɣ n tiwuriwin n umsqdac ad',
'tooltip-t-emailuser' => 'Ṣafd tabrat umsqdac ad',
'tooltip-t-upload' => 'sɣlid ifaylutn',
'tooltip-t-specialpages' => 'Umuɣ n tisniwin timẓlayin',
'tooltip-t-print' => 'Lqim uziggz n tasna yad',
'tooltip-t-permalink' => 'Azday bdda i lqim n tasna yad',
'tooltip-ca-nstab-main' => 'Ẓr mayllan ɣ tasna',
'tooltip-ca-nstab-user' => 'Ẓr tasna n useqdac',
'tooltip-ca-nstab-media' => 'Iẓri n tasna n midya',
'tooltip-ca-nstab-special' => 'Tasna yad tuyẓlay, uras tufit ast ẓregt(tbddelt) nttat nit',
'tooltip-ca-nstab-project' => 'Żr tasna n twwuri',
'tooltip-ca-nstab-image' => 'Źr tasna n usdaw',
'tooltip-ca-nstab-mediawiki' => 'Żr tabrat nu-nagraw.',
'tooltip-ca-nstab-template' => 'Żr tamudemt',
'tooltip-ca-nstab-help' => 'Źr tasna nu-saws',
'tooltip-ca-nstab-category' => 'Źr tasna nu-stay',
'tooltip-minoredit' => 'Kerj ażřigad mas ifssus',
'tooltip-save' => 'Ḥbu imbddel nek',
'tooltip-preview' => 'Mel(fsr) imbddeln nek, urat tḥibit matskert',
'tooltip-diff' => 'Mel (fsr) imbddeln li tskert u-ṭṛiṣ',
'tooltip-compareselectedversions' => 'Ẓr inaḥyatn gr sin lqimat li ttuystaynin ɣ tasna yad.',
'tooltip-watch' => 'Smdn tasna yad i tilli tsggat.',
'tooltip-recreate' => 'Als askr n tasna yad waxxa ttuwḥiyyad',
'tooltip-upload' => 'Izwir siɣ tullt.',
'tooltip-rollback' => '"Rard" s yan klik ażrig (iżrign) s ɣiklli sttin kkan tiklit li igguran',
'tooltip-undo' => '"Sglb" ḥiyd ambdl ad t mmurẓmt tasatmt n umbdl ɣ umuḍ tiẓri tamzwarut.',
'tooltip-summary' => 'Skcm yat tayafut imẓẓin',

# Browsing diffs
'previousdiff' => 'Imbddln imzwura',
'nextdiff' => 'Ambdl d ittfrn  →',

# Media information
'file-info-size' => '$1 × $2 piksil, asdaw tugut: $3, MIME anaw: $4',
'file-nohires' => '↓Ur tlli tabudut tamqrant.',
'svg-long-desc' => 'Asdaw SVG, Tabadut n $1 × $2 ifrdan, Tiddi : $3',
'show-big-image' => 'balak',

# Bad image list
'bad_image_list' => 'zud ghikad :

ghir lhwayj n lista (stour libdounin s *) karaytyo7asab',

# Variants for Tachelhit language
'variantname-shi-tfng' => 'ⵜⴰⵛⵍⵃⵉⵜ',
'variantname-shi-latn' => 'Tašlḥiyt',
'variantname-shi' => 'disable',

# Metadata
'metadata' => 'isfka n mita',
'metadata-help' => 'Asdaw ad llan gis inɣmisn yaḍnin lli tfl lkamira tuṭunit niɣd aṣfḍ n uxddam lliɣ ay sgadda asdaw ad',
'metadata-expand' => 'Ml ifruriyn lluzzanin',
'metadata-collapse' => 'Aḥbu n ifruriyn lluzzanin',
'metadata-fields' => 'Igran n isfkan n metadata li illan ɣ tabratad ran ilin ɣ tawlaf n tasna iɣ mzzin tiflut n isfka n mita
Wiyyaḍ raggis ḥbun s ɣiklli sttin kkan gantn.
* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* isospeedratings
* focallength
* artist
* copyright
* imagedescription
* gpslatitude
* gpslongitude
* gpsaltitude',

'exif-exposureprogram-1' => 'w-ofoss',

'exif-subjectdistance-value' => '$1 metro',

'exif-meteringmode-0' => 'orityawssan',
'exif-meteringmode-1' => 'moyen',
'exif-meteringmode-2' => 'moyen igiddi gh tozzomt',
'exif-meteringmode-3' => 'tanqqit',
'exif-meteringmode-4' => 'MultiSpot',
'exif-meteringmode-5' => 'agaw',
'exif-meteringmode-6' => 'ghar imik giss',
'exif-meteringmode-255' => 'wayya',

'exif-lightsource-0' => 'orityawssan',
'exif-lightsource-1' => 'dow n wass',
'exif-lightsource-2' => 'Fluorescent',
'exif-lightsource-3' => 'dow ijhddn',
'exif-lightsource-4' => 'lflash',
'exif-lightsource-9' => 'ljow ifolkin',
'exif-lightsource-10' => 'tagot',
'exif-lightsource-11' => 'asklo',

'exif-sensingmethod-2' => 'amfay n lon n tozmi ghyat tosa',
'exif-sensingmethod-3' => 'amfay n lon n tozmi ghsnat tosatin',

'exif-gaincontrol-0' => 'walo',

'exif-contrast-0' => 'normal',
'exif-contrast-1' => 'irtb',
'exif-contrast-2' => 'iqor',

'exif-saturation-0' => 'normal',
'exif-saturation-1' => 'imik ntmlli',
'exif-saturation-2' => 'kigan ntmlli',

'exif-sharpness-0' => 'normal',
'exif-sharpness-1' => 'irtb',
'exif-sharpness-2' => 'iqor',

'exif-subjectdistancerange-0' => 'orityawssan',
'exif-subjectdistancerange-1' => 'Macro',
'exif-subjectdistancerange-2' => 'tannayt iqrbn',

# Pseudotags used for GPSLatitudeRef and GPSDestLatitudeRef
'exif-gpslatitude-n' => 'dairat lard chamaliya',

# Pseudotags used for GPSSpeedRef
'exif-gpsspeed-n' => 'Knots',

# External editor support
'edit-externally' => 'Bddl asdaw ad s wasnas abrrani',
'edit-externally-help' => '(Ẓṛ [//www.mediawiki.org/wiki/Manual:External_editors/fr les instructions d’installation] bac ad taf uggar n inɣmisn)',

# 'all' in various places, this might be different for inflected languages
'watchlistall2' => 'kraygat (kullu)',
'namespacesall' => 'kullu',
'monthsall' => 'kullu',
'limitall' => 'Kullu',

# Delete conflict
'recreate' => 'awd skr',

# action=purge
'confirm_purge_button' => 'Waxxa',

# Multipage image navigation
'imgmultigo' => 'ballak !',

# Table pager
'ascending_abbrev' => 'aryaqliw',
'descending_abbrev' => 'aritgiiz',
'table_pager_next' => 'tawriqt tamaynut',
'table_pager_prev' => 'tawriqt izrin',
'table_pager_first' => 'tawriqt tamzwarut',
'table_pager_last' => 'tawriqt tamgrut',
'table_pager_limit_submit' => 'ballak',
'table_pager_empty' => 'ornofa amya',

# Watchlist editor
'watchlistedit-normal-submit' => 'hiyd lanawin',
'watchlistedit-raw-titles' => 'Azwl',

# Watchlist editing tools
'watchlisttools-view' => 'Umuɣ n imtfrn',
'watchlisttools-edit' => 'Ẓr tẓṛgt umuɣ lli tuytfarn',
'watchlisttools-raw' => 'Ẓṛig umuɣ n tisniwin',

# Core parser functions
'duplicate-defaultsort' => 'Balak: tasarut n ustay « $2 » ar tbj tallit izwarn« $1 ».',

# Special:Version
'version' => 'noskha',
'version-specialpages' => 'Tisnatin timzlay',
'version-parserhooks' => 'khatatif lmohallil',
'version-variables' => 'lmotaghayirat',
'version-other' => 'wayya',
'version-mediahandlers' => 'motahakkimat lmedia',
'version-hooks' => 'lkhtatif',
'version-extension-functions' => 'lkhdaym n limtidad',
'version-parser-extensiontags' => 'imarkiwn n limtidad n lmohalil',
'version-parser-function-hooks' => 'lkhtatif ndala',
'version-poweredby-others' => 'wiyyad',
'version-software-product' => 'lmntoj',
'version-software-version' => 'noskha',

# Special:FilePath
'filepath-page' => 'Asdaw:',
'filepath-submit' => 'Ftu',

# Special:FileDuplicateSearch
'fileduplicatesearch-filename' => 'smiyt n-wasdaw:',
'fileduplicatesearch-submit' => 'Sigl',

# Special:SpecialPages
'specialpages' => 'tiwriqin tesbtarin',
'specialpages-group-other' => 'tiwriqin khassa yadnin',
'specialpages-group-login' => 'kchm/sjl',
'specialpages-group-changes' => 'tghyirat granin d sijilat',
'specialpages-group-media' => 'taqarir n lmedia d upload',
'specialpages-group-users' => 'imskhdamn d salahiyat',
'specialpages-group-highuse' => 'tiwriqim li bahra skhdamn midn',
'specialpages-group-pages' => 'lista n twriqin',
'specialpages-group-pagetools' => 'tawriqt n ladawat',
'specialpages-group-wiki' => 'wiki ladawat dlmalomat',
'specialpages-group-redirects' => 'sfhat tahwil gant khassa',
'specialpages-group-spam' => 'ladawat n spam',

# Special:BlankPage
'blankpage' => 'tawriqt orgiss walo',

# External image whitelist
'external_image_whitelist' => '# Ajji aṣṭtar nna ɣiklli iga. <pre>
# Ml igzman n tannayin (ɣir imi lli illan gr//) ɣ uzddar ɣid.
# Rad tmiqqirn d tansiwin URL n tiwlaf n brra.
# Tilli dis tmiqqirnin rad baynt zund tiwlaf, niɣd yan uzday s tawlaft arad ibayn.
# Isṭṭarn lli ittizwirn s # rad gin zund iwnnan.
# Tasna yad tfta d ugmmaḍ ad

# Gatn igzman n iwnnan ɣ uflla n usṭṭar ad. Ajji yataṣṭṭar amggaru ɣiklli iga. </pre>',

# Special:Tags
'tag-filter' => 'Astay n [[Special:Tags|balises]] :',
'tag-filter-submit' => 'Istayn',
'tags-title' => 'imarkiwn',
'tags-hitcount-header' => 'tghyiran markanin',
'tags-edit' => 'bddl',

# Special:ComparePages
'comparepages' => 'qarnn tiwriqin',
'compare-selector' => 'qarn lmorajaa ntwriqin',
'compare-page1' => 'tawriqt 1',
'compare-page2' => 'tawriqt 2',
'compare-rev1' => 'morajaa 1',
'compare-rev2' => 'morajaa 2',
'compare-submit' => 'qarn',

# HTML forms
'htmlform-submit' => 'sifd',
'htmlform-reset' => 'sglbd tghyirat',
'htmlform-selectorother-other' => 'wayya',

# New logging system
'revdelete-restricted' => 'iskr aqn i indbaln',
'revdelete-unrestricted' => 'Aqn iḥiyd i indbaln',
'rightsnone' => '(ḥtta yan)',

);
