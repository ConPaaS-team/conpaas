<?php
/** Austrian German (Österreichisches Deutsch)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Geitost
 * @author Laximilian scoken
 * @author Mucalexx
 * @author Revolus
 * @author Wdwd
 * @author ✓
 */

$fallback = 'de';

$messages = array(
# Dates
'january' => 'Jänner',
'february' => 'Februar',
'december' => 'Dezember',
'january-gen' => 'Jänners',
'february-gen' => 'Febers',
'jan' => 'Jän',

);
