<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'mysqldb');

/** MySQL database password */
define('DB_PASSWORD', 'contrail123');

/** MySQL hostname */
define('DB_HOST', getenv('MYSQL_IP'));

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '{y ttOA^TYdU<DL~Mu;ZC53>Dga)BIHuJJ $$z.qMoIMfa+O6Yi[CBpZ@|<{-];v');
define('SECURE_AUTH_KEY',  'E%na1}xc|z6C8E+<uF8 [Y+f=MmGeZY$!v@@c|G-}%@Wth&*iai7VexH5->+A!SU');
define('LOGGED_IN_KEY',    ':@~etu~Vh.8G-#C8YbOR6DTjQ/2tNlb)&c^L8_6r,MhHUhaTT RJjU6VySzb,D3,');
define('NONCE_KEY',        'AFHuzITY[}%**#c^#Ucn?3IQ-dN~fyC`CZ10BB-.)&JaD<7IX$KDVQb5Ueqv?DHx');
define('AUTH_SALT',        ':BfJPRq{MqM9UZZ3PCDL~czn_)0:(MO6,3!1L#e8Cm_nU06plq_&VU=Ugc,]$lmh');
define('SECURE_AUTH_SALT', 'y]|qW;/ FslWt(G`--N7;L; /s AZM)N)+F]CIMb3<`vwy7UCR]sgOZk)5_rrWI1');
define('LOGGED_IN_SALT',   ' WW-qhN6>~Yw)$mL78oc-%f0Z-XDqeF<K]iMvqocB5=EQQ ew9a@E2XJIu9CA-<X');
define('NONCE_SALT',       'D@*{0IhG|xk~Z.KcBTQx_:NC@kUR,}{4jr`w$A-_CYd)q_C%1$D`@3ikL#@1!POI');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
